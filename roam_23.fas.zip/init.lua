user_permission={
  [4]	= "READ_INSTALL_SESSIONS" ;
  [1]	= "ACCESS_NETWORK_STATE" ;
  [2]	= "ACCESS_WIFI_STATE" ;
  [3]	= "INTERNET" ;
  } ;
template="bottom"
appcode="23002000"
appname="ROAM"
appver="23.0.0"
packagename="com.addplus.PBA.newyear"

--require "import" import"loadlayout" import"loadmenu" import"loadbitmap" 