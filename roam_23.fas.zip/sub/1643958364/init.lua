name="PrivacyMode"
template="tool"
