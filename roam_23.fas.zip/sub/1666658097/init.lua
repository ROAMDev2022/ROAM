name="DeleteUpSide"
template="tool"
